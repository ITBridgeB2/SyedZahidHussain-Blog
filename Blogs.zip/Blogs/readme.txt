create app  with any new project name

2. paste the src in the Src of that project.
3. paste the server1.js in the express Module.
>>>Existing Table (select * from posts)==>POSTS
    mysql> select * from posts;
+----+----------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-----------+---------------------+
| id | title          | content                                                                                                                                                                                                               | author    | created_at          |
+----+----------------+-------------------------------------------------------------------------------------------
    >>>>CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP );
